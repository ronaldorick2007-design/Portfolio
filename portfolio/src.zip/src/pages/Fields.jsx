import Header from "../components/Header";
import { useState } from "react";
import Code_Visual from "../components/Code_Visual";
import Code_VisualStack from "../components/Code_VisualStackAgain";

import palindrome from "../algorithms/Miscellanous/palindrome";
import highlight from "../algorithms/Miscellanous/highlight";

import sll_traversal from "../algorithms/linked_list/sll_traversal";
import dll_traversal from "../algorithms/linked_list/dll_traversal";

import stack_basic from "../algorithms/stack/stack_basic";
import queue_basic from "../algorithms/queue/queue_basic";

import linearSearch from "../algorithms/Arrays/linearSearch";
import binarySearch from "../algorithms/Arrays/binarySearch";
import bubbleSort from "../algorithms/Arrays/bubbleSort";
import insertionSort from "../algorithms/Arrays/insertionSort";
import selectionSort from "../algorithms/Arrays/selectionSort";

import whileLoop from "../algorithms/basics/whileLoop";
import forLoop from "../algorithms/basics/forLoop";
import selection from "../algorithms/basics/selection";
import updation from "../algorithms/basics/updation";

import main_preorder from "../algorithms/trees/preorder";
import main_postorder from "../algorithms/trees/postorder";
import main_inorder from "../algorithms/trees/inorder";

import { codeForAll } from "../components/Code_Lines";

// import LinkedList from "../components/LinkingList";

export default function Fields(){
    const fieldsMap = {
        "Basics":[
                <Code_VisualStack key="while" title={"While Loop"} codes={codeForAll.WHILE_LOOP} generator={whileLoop}/>,
                <Code_VisualStack key="forloop" title={"For Loop"} codes={codeForAll.FOR_LOOP} generator={forLoop}/>,
                <Code_VisualStack key="select" title={"If-Else Statement"} codes={codeForAll.SELECTION} generator={selection}/>,
                <Code_VisualStack key="updation" title={"Updation"} codes={codeForAll.UPDATION} generator={updation}/>,
            ],

        "Search":[
                <Code_VisualStack key="linear" title={"Linear Search"} codes={codeForAll.LINEAR_SEARCH} generator={linearSearch}/>,
                <Code_VisualStack key="binary" title={"Binary Search"} codes={codeForAll.BINARY_SEARCH} generator={binarySearch}/>
            ], 

        "Sort":[
                <Code_VisualStack key="bubble" title={"Bubble Sort"} codes={codeForAll.BUBBLE_SORT} generator={bubbleSort}/>,
                <Code_VisualStack key="insertion" title={"Insertion Sort"} codes={codeForAll.INSERTION_SORT} generator={insertionSort}/>,
                <Code_VisualStack key="selection" title={"Selection Sort"} codes={codeForAll.SELECTION_SORT} generator={selectionSort}/>
            ],

        "Linked Lists":[
                <Code_VisualStack key="traversal_sll" title={"Singly Linked List"} codes={codeForAll.SLL_TRAVERSAL} generator={sll_traversal}/>,
                <Code_VisualStack key="traversal_dll" title={"Doubly Linked List"} codes={codeForAll.DLL_TRAVERSAL} generator={dll_traversal}/>
            ],

        "Stacks":[ 
                <Code_VisualStack key="stack" title={"Stack"} generator={stack_basic}/>
            ],

        "Queues":[
                <Code_VisualStack key="queue" title={"Queue"} generator={queue_basic}/>
            ],

        "Trees":[
                <Code_VisualStack key="preorder" title={"Tree Preorder"} generator={main_preorder}/>,
                <Code_VisualStack key="postorder" title={"Tree Postorder"} generator={main_postorder}/>,
                <Code_VisualStack key="inorder" title={"Tree Inorder"} generator={main_inorder}/>
            ],

        "Miscellanous" : [
                <Code_VisualStack key="palindrome" title={"Palindrome"} generator={palindrome}/>,
                <Code_VisualStack key="highlight" title={"Highlight"} generator={highlight}/>
            ],

        "Leetcode" :[]
        };

function useFields() {
  const [code, setCode] = useState("Basics");
  const items = fieldsMap[code] || [];

  return { code, setCode, items };
}

 const {code, setCode, items} = useFields();

    return(
        <>
        <div className="animate-fade-in"><Header /></div>
        
        <div className="p-4 gap-4 flex h-screen">
            <div className="bg-amber-300 flex-1">
                {Object.keys(fieldsMap).map((field, i) => {
                    return(<div key={i} className="p-2 m-2 text-center bg-green-400 hover:bg-amber-300 transition-all duration-150 ease-in-out" onClick={() => {setCode(field)}}>{field}</div>)
                })}
            </div>
            <div className="bg-amber-300 flex-4 flex-col p-2 gap-4 overflow-auto">
                {code}
                {items.map((field) => {
                    return(field);
                }) }             
                </div>
        </div>
        </>
    );
}
