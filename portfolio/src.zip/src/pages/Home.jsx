import RippleField from "../components/RippleField";
import Header from "../components/Header";
import Footer from "../components/Footer";
import Welcome from "../components/Welcome";

import { useTheme } from "../components/ThemeProvider";
import { themes } from "../styles/themes";

export default function Home(){
  const { theme } = useTheme();
  return(
    <div className={themes.home[theme]}>
    <div className="animate-fade-in"><Header /></div>    

  <div className="relative flex h-screen -mt-10 items-center justify-center overflow-hidden">
    <div className="absolute inset-0 z-0 flex items-center justify-center">
      <div className="animate-fade-in"><RippleField /></div>
      
    </div>
    <div className="pointer-events-none z-10">
      <div className="animate-fade-in [animation-delay:250ms]"><Welcome /></div>
      
    </div>
  </div>

  <div className = "flex items-center justify-center p-8 gap-8">

    <div className="border-2 border-black bg-[#f8ff2b] flex-1 justify-center h-[75vh] text-2xl font-medium flex flex-col gap-12 text-center p-5 hover:scale-95 hover:shadow-[10px_10px_#000] transition-all duration-300 ease-in-out">
      <h2 className="text-4xl font-bold after:content-['|'] after:animate-blink ">About Me</h2>
    <p>
      Hello! I'm Ronald, a Computer Science student who enjoys building
      software and learning how systems work behind the scenes
    </p>

    <p>
      I enjoy turning ideas into practical projects, whether it's developing
      visual algorithms, designing user interfaces, or experimenting with new
      technologies.
    </p>
    </div>

    <div className="border-2 border-black bg-[#f8ff2b] flex-1 justify-center h-[75vh] text-2xl font-medium flex flex-col  text-center p-5 hover:scale-95 hover:shadow-[10px_10px_#000] transition-all duration-300 ease-in-out">
        <h3 className="text-4xl font-bold after:content-['|'] after:animate-blink mb-2">Currently Learning</h3>
        <p className="text-cyan-400">• Data Structures and Algorithms</p>
        <p>• JavaScript (ES6+), Python & C</p>
        <p>• Node.js & Express</p>
        <p>• SQL & Databases</p>
        <p>• React & TailwindCSS</p>
        <p>• Git & GitHub</p>    
      </div>   

    </div>

  <div className = "flex items-center justify-center p-8 gap-8">
    <div className="border-2 border-black bg-[#36deff] flex-1 justify-center h-[50vh] text-2xl font-medium flex flex-col gap-12 text-center p-5 hover:scale-95 hover:shadow-[10px_10px_#000] transition-all duration-300 ease-in-out">
      <h1 className="text-4xl font-bold after:content-['|'] after:animate-blink">This is my personality</h1>
      <p>This section is under construction</p>
    </div>
  </div>

  <div className = "flex p-8 gap-8">
    <div className="border-2 border-black bg-[#89FC00] flex-1 justify-center h-[50vh] text-2xl font-medium flex flex-col gap-12 text-center p-5 hover:scale-95 hover:shadow-[10px_10px_#000] transition-all duration-300 ease-in-out">      
      <h2 className="font-bold">Project 1</h2>
      <p>This is the description for Project 1.</p>    
    </div>

    <div className="border-2 border-black bg-[#89FC00] flex-1 justify-center h-[50vh] text-2xl font-medium flex flex-col gap-12 text-center p-5 hover:scale-95 hover:shadow-[10px_10px_#000] transition-all duration-300 ease-in-out">      
      <h2 className="font-bold">Project 2</h2>
      <p>This is the description for Project 2.</p>    
    </div>

    <div className="border-2 border-black bg-[#89FC00] flex-1 justify-center h-[50vh] text-2xl font-medium flex flex-col gap-12 text-center p-5 hover:scale-95 hover:shadow-[10px_10px_#000] transition-all duration-300 ease-in-out">      
      <h2 className="font-bold">Project 3</h2>
      <p>This is the description for Project 3.</p>    
    </div>
    
  </div>

  <Footer />
</div>
  );
}

