// import "../styles/Body.css"
import "../styles/Grid.css"
import { useState } from "react";
import Footer from "../components/Footer";
import Header from "../components/Header";
import parse from "../algorithms/Miscellanous/parser"
import main from "../algorithms/Miscellanous/bie";

import { useTheme } from "../components/ThemeProvider";
import { themes } from "../styles/themes";
import TerminalCode from "../components/TerminalCode";
 
import CompetentRenderStack from "../components/CompetentRenderStackAgainCopy";
import TerminalCode1 from "../components/TerminalCode1";
// import main from "../algorithms/leetcode/two_sum";
import Graph from "../components/GraphCopy";
import binarySearch from "../algorithms/Arrays/binarySearch";
import main_mergesort from "../algorithms/Miscellanous/mergeSort";



export default function Codes(){
  main()
    const [code, setCode] = useState(`function bubbleSort(arr) {

  for (let i = 0; i < arr.length - 1; i++) {

    for (let j = 0; j < arr.length - i - 1; j++) {

      $arr->[i,j]->active

      if (arr[j] > arr[j + 1]) {
        [arr[j], arr[j+1]] =
        [arr[j+1], arr[j]];
      }

    }
  }

  return arr;
}

function main() {

  let arr = [5, 3, 8, 4, 2];

  return bubbleSort(arr);
}`);

  const [generator, setGenerator] = useState(null);

  // -----------------------------
  // REPARSE
  // -----------------------------

  function reparse() {
    try {

      const parsed = parse(code);

      console.log("REPARSED:");
      console.log(parsed);

      // Replace editor contents
      setCode(parsed);

    } catch (error) {
      console.error("REPARSE ERROR:", error);
    }
  }

  // -----------------------------
  // RUN
  // -----------------------------

  function run() {
    try {

      const main = new Function(`
        ${code}

        return main;
      `)();

      setGenerator(() => main);

    } catch (error) {
      console.error("RUN ERROR:", error);
    }
  }

  return (
    <div className="min-h-screen bg-white p-10">

      <TerminalCode1
        content={code}
        onChange={setCode}
        onReparse={reparse}
        onRun={run}
      />

      {generator && (
        <div className="mt-10">
          <CompetentRenderStack generator={generator} />
        </div>
      )}

    </div>
  );
}
