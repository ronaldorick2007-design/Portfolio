export default function HashSet({
    arr,
    name,
    indicate={},
    size = 50,
    gap = 10
}) { 
    const step = size + gap;
    const n = arr.length;
 
    return <div className="container border-2" style={{width : `${n!=0 ? n*step : 100}px`,height : `${size*2}px`, paddingTop : `${size/2}px`,paddingLeft : `${gap/2}px`}}>
        <div className="-mt-5">{name}</div>
        {arr.map((value, i) => (
            <div key={i} className="box-wrapper">
                <div
                    className={`box ${indicate.get(value) ? indicate.get(value) : "" }`}
                    style={{
                        width: `${size}px`,
                        height: `${size}px`,
                        transform: `translateX(${i * step}px)`,
                    }}
                >
                    {value.toString()}
                </div>
                
            </div>
        )
    )}</div>;
}