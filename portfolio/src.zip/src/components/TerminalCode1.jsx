import React, { useMemo, useRef, useState } from "react";

function highlightYield(code, hideYield) {
  const parts = [];
  let i = 0;

  while (i < code.length) {
    const match = code.slice(i).match(/^yield\s*\[/);

    if (!match) {
      const start = i;

      while (
        i < code.length &&
        !/^yield\s*\[/.test(code.slice(i))
      ) {
        i++;
      }

      parts.push(
        <span key={start} className="text-white">
          {code.slice(start, i)}
        </span>
      );

      continue;
    }

    const start = i;

    i += match[0].length;

    let depth = 1;

    while (i < code.length && depth > 0) {
      if (code[i] === "[") depth++;
      if (code[i] === "]") depth--;
      i++;
    }

    if (code[i] === ";") {
      i++;
    }

    parts.push(
      <span
        key={start}
        className={hideYield ? "text-transparent" : "text-zinc-500"}
      >
        {code.slice(start, i)}
      </span>
    );
  }

  return parts;
}

export default function TerminalCode1({
  content,
  onChange,
  onReparse,
  onRun,
}) {
  const [hideYield, setHideYield] = useState(false);

  const textareaRef = useRef(null);
  const highlightRef = useRef(null);

  const highlighted = useMemo(
    () => highlightYield(content, hideYield),
    [content, hideYield]
  );

  function handleScroll(e) {
    const textarea = e.target;
    const highlight = highlightRef.current;

    if (!highlight) return;

    highlight.scrollTop = textarea.scrollTop;
    highlight.scrollLeft = textarea.scrollLeft;
  }

  return (
    <div className="w-full overflow-hidden border border-zinc-800 bg-black">

      {/* HEADER */}
      <div className="flex h-10 items-center border-b border-zinc-800 bg-zinc-950 px-4">

        <div className="flex gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-red-500" />
          <span className="h-2.5 w-2.5 rounded-full bg-yellow-500" />
          <span className="h-2.5 w-2.5 rounded-full bg-green-500" />
        </div>

        <span className="ml-4 text-xs text-zinc-500">
          editor.js
        </span>

        <div className="ml-auto flex gap-2">

          <button
            onClick={onReparse}
            className="rounded px-3 py-1 text-xs text-zinc-500 hover:bg-zinc-800 hover:text-white"
          >
            Reparse
          </button>

          <button
            onClick={onRun}
            className="rounded px-3 py-1 text-xs text-zinc-500 hover:bg-zinc-800 hover:text-white"
          >
            Run
          </button>

          <button
            onClick={() => setHideYield((v) => !v)}
            className="rounded px-3 py-1 text-xs text-zinc-500 hover:bg-zinc-800 hover:text-white"
          >
            {hideYield ? "Reveal yields" : "Hide yields"}
          </button>

        </div>
      </div>

      {/* EDITOR */}
      <div className="relative h-[500px]">

        {/* VISUAL LAYER */}
        <pre
          ref={highlightRef}
          aria-hidden="true"
          className="
            pointer-events-none
            absolute
            inset-0
            min-h-[500px]
            m-0
            overflow-hidden
            whitespace-pre
            p-5
            font-mono
            text-[15px]
            leading-6
          "
        >
          {highlighted}
        </pre>

        {/* ACTUAL EDITOR */}
        <textarea
          ref={textareaRef}
          value={content}
          onChange={(e) => onChange(e.target.value)}
          onScroll={handleScroll}
          spellCheck={false}
          autoComplete="off"
          wrap="off"
          className="
            absolute
            inset-0
            z-10
            
            w-full
            resize-none
            overflow-auto
            bg-transparent
            p-5
            font-mono
            text-[15px]
            leading-6
            text-transparent
            caret-white
            outline-none
            selection:bg-zinc-700
            selection:text-white
          "
        />

      </div>
    </div>
  );
}