import React, { useState } from "react";

function highlightYield(content, hideYield) {
  const parts = [];
  let i = 0;

  while (i < content.length) {
    if (/^yield\s*\[/.test(content.slice(i))) {
      const start = i;

      const match = content.slice(i).match(/^yield\s*\[/);
      i += match[0].length;

      let depth = 1;

      while (i < content.length && depth > 0) {
        if (content[i] === "[") depth++;
        if (content[i] === "]") depth--;
        i++;
      }

      // Include optional semicolon
      if (content[i] === ";") {
        i++;
      }

      parts.push(
        <span
          key={start}
          className={hideYield ? "hidden" : "text-zinc-500"}
        >
          {content.slice(start, i)}
        </span>
      );
    } else {
      const start = i;

      while (
        i < content.length &&
        !/^yield\s*\[/.test(content.slice(i))
      ) {
        i++;
      }

      parts.push(
        <span key={start} className="text-white">
          {content.slice(start, i)}
        </span>
      );
    }
  }

  return parts;
}
export default function TerminalCode({ content }) {
  const [hideYield, setHideYield] = useState(false);

  return (
    <div className="w-full overflow-hidden rounded-none border border-zinc-800 bg-black">
      
      {/* Header */}
      <div className="relative flex h-9 items-center border-b border-zinc-800 bg-zinc-950 px-4">
        <div className="flex gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-red-500" />
          <span className="h-2.5 w-2.5 rounded-full bg-yellow-500" />
          <span className="h-2.5 w-2.5 rounded-full bg-green-500" />
        </div>

        {/* Button */}
        <button
          onClick={() => setHideYield(!hideYield)}
          className="absolute right-3 text-xs text-zinc-500 hover:text-white"
        >
          {hideYield ? "Show yields" : "Hide yields"}
        </button>
      </div>

      {/* Code */}
      <div className="max-h-[500px] overflow-auto whitespace-pre p-5 font-mono text-sm leading-7">
        {highlightYield(content, hideYield)}
      </div>
    </div>
  );
}