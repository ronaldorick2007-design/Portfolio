import Terminal from "./Terminal";

export default function Welcome(){
    return(
        <div className="w-[650px]  border-2 border-black bg-[#ff5bfc92] transition-all duration-300 ease-in-out pointer-events-none ">
            <div className="flex h-[42px] items-center justify-between border-b-2 border-black p-3 bg-white">
                <div className="flex gap-2">
                    <span className="size-3 rounded-full border-2 border-black bg-[#ff5f57] animate-[move_1s_infinite]" />

                    <span className="size-3 rounded-full border-2 border-black bg-[#febc2e] animate-[move_1s_0.2s_infinite]" />

                    <span className="size-3 rounded-full border-2 border-black bg-[#28c840] animate-[move_1s_0.4s_infinite]" />
                </div>
                <button>Copy</button>
            </div>
            <div className="h-[500px] p-5"> <Terminal /> </div>
        </div>
    );
}
