export default function Stack({
    arr,
    active = [],
    match = [],
    pass = [],
    hold = [],
    cut = [],
    swap,
    size = 50,
    gap = 10
}) {
    const step = size + gap;

    return <div className="h-25 w-60" >
        {arr.map((value, i) => (
        <div
            key={i}
            className="box-wrapper"
            style={{
                transform: `translateY(${i * step}px)`,
                transition: "transform 0.25s ease"
            }}
        >
            <div
                className={`box ${value.status}`}
                style={{
                    width: `${size*2}px`,
                    height: `${size}px`,
                }}
            >
                {value.toString()}
            </div>
        </div>
    ))}
    </div>;
}
