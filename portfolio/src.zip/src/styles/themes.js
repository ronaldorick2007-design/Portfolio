export const themes = {
  Header: {
  light: "mt-0.5 ml-[4.5%] w-[90%] flex items-center justify-between bg-gray-100 p-5 text-gray-900 border border-gray-200",
  
  dark: "mt-0.5 ml-[4.5%] w-[90%] flex items-center justify-between bg-black p-5 text-white border border-gray-800",
},

body:{
    light: "bg-white flex flex-col items-center p-5 g-5",
    dark: "bg-black flex flex-col items-center p-5 g-5 text-white",
},


home:{
    light: "bg-white",
    dark: "bg-black text-white",
},

  B: {
    light: "bg-blue-100 text-blue-900 border border-blue-200",
    dark: "bg-blue-950 text-blue-100 border border-blue-800",
  },
};