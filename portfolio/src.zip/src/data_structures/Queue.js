import { Node } from "./Node";
export class Queue{
    constructor(){
        this.head = null;
        this.tail = null;
        this.size = 0;
    }
    isEmpty(){
        return this.size == 0;
    }
    enqueue(value){
        let newNode = new Node(value);
        if(this.isEmpty()){
            this.head = this.tail = newNode;
            this.size++;
        }
        else{
            this.tail.next = newNode;
            this.tail = newNode;
            this.size++;
        }
    }
    dequeue(){
        if(this.isEmpty()){
            return null;
        }
        else{
            let temp = this.head;
            this.head = this.head.next;
            this.size--;
            return temp.value;
        }
    }
    peek(){
        if(this.isEmpty()){
            return null;
        }
        else{
            return this.head.value;
        }
    }
}