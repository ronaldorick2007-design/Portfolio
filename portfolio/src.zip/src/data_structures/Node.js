export class Node{
    constructor(value){
        this.value = value;
        this.next = null;
        this.prev = null;
        this.status = "";
    }

    toString(){
        return this.value.toString();
    }

}