import { Node } from "./Node";
export class Stack{
    constructor(){
        this.head = null;
        this.size = 0;
        this.capacity = 5;
    }
    isEmpty(){
        return this.size == 0;
    }
    push(value){
        let newNode = new Node(value);
        if(this.isEmpty()){
            this.head = newNode;
            this.size++;
        }
        else{
            newNode.next = this.head;
            this.head = newNode;
            this.size++;
        }
    }
    pop(){
        if(this.isEmpty()){
            return null;
        }
        else{
            let temp = this.head;
            this.head = this.head.next;
            this.size--;
            return temp;
        }
    }
    peek(){
        if(this.isEmpty()){
            return null;
        }
        else{
            return this.head.value;
        }
    }
}