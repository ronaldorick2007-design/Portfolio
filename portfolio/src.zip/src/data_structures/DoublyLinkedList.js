import { Node } from "./Node";

export class DoublyLinkedList{
    constructor(){
        this.head = null;
        this.tail = null;
        this.size = 0;
    }

    isEmpty(){
        return this.size == 0;
    }

    insert_at_k(value, k){
        if(k < 0 || k > this.size-1 ) return null;
        if(this.isEmpty() || k == 0) this.add_at_head(value);
        if(k == this.size - 1) this.add_at_tail(value);

        let i = 0;
        let curr = this.head;
        while(curr != null && i != k){
            curr = curr.next;
            i++
        }

        let newNode = new Node(value);
        newNode.next = curr.next;
        newNode.prev = curr;
        curr.next = newNode;
        newNode.next.prev = newNode;
    }

    delete_at_k(k){
        if(k < 0 || k > this.size-1 ) return null;
        if(k == 0) this.pop_at_head(value);
        if(k == this.size - 1) this.pop_at_tail(value);

        let i = 0;
        let curr = this.head;
        while(curr != null && i != k){
            curr = curr.next;
            i++
        }

        curr.next = curr.next.next;
        curr.next.prev = curr;
    }

    add_at_head(value){
        let newNode = new Node(value);
        if(this.isEmpty()){
            this.head = this.tail = newNode;
        }
        else{
            newNode.next = this.head;
            this.head.prev = newNode;
            this.head = newNode;
        }
        this.size++;
    }

    add_at_tail(value){
        let newNode = new Node(value);
        if(this.isEmpty()){
            this.head = this.tail = newNode;
        }
        else{
            this.tail.next = newNode;
            newNode.prev = this.tail;
            this.tail = newNode;
        }
        this.size++;
    }

    add(value){
        this.add_at_tail(value);
    }

    pop_at_head(){
        if(this.isEmpty()) return null;
        let temp = this.head;
        this.head = this.head.next;
        this.head.prev = null;
        this.size--;
        return temp.value;
    }

    pop_at_tail(){
        if(this.isEmpty()) return null;

        let temp = this.tail;

        let curr = this.head
        if(curr.next == null)this.head = this.tail = null;
        else{
            while(curr.next.next != null) curr = curr.next;        
            curr.next = null;
            this.tail = curr;
            this.size--;
        }
        return temp.value;
    }

    pop(){
        this.pop_at_tail();
    }
    
}