export class TreeNode{
    static id = 0;
    constructor(value){
        this.value = value;
        this.id = this.id++;
        this.left = null;
        this.right = null;
        this.status = "";
    }
    
    toString(){
        return `${this.value}`
    }
}