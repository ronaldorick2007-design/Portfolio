import { useState, useCallback } from "react";

export function useScopes(initialData = []) {
  // Structure: [["nameName", { name, value, status }, ...], ...]
  const [grid, setGrid] = useState(initialData);

  // 1. check(name): checks if a name row exists (where row[0] === name)
  const check = useCallback(
    (name) => grid.some((row) => row[0] === name),
    [grid]
  );

  // 2. set(name): adds a new row ["name"] if it doesn't already exist
  const set = useCallback((name) => {
    setGrid((prev) => {
      if (prev.some((row) => row[0] === name)) return prev;
      return [...prev, [name]];
    });
  }, []);

  // 3. write_name(name, data):
  // Finds row where row[0] === name.
  // Iterates from index 1: if item.name === data.name, overwrites it;
  // if no matching object or no objects exist, appends to the row.
  const write_name = useCallback((name, data) => {
    setGrid((prev) => {
      const rowIndex = prev.findIndex((row) => row[0] === name);

      // If the name row doesn't exist at all, create it with the object
      if (rowIndex === -1) {
        return [...prev, [name, data]];
      }

      const targetRow = prev[rowIndex];
      let itemFound = false;

      // Map through elements: index 0 is name name, 1+ are objects
      const updatedRow = targetRow.map((elem, idx) => {
        if (idx === 0) return elem; // Keep name name
        if (elem.name === data.name) {
          itemFound = true;
          return data; // Overwrite
        }
        return elem;
      });

      // If no matching object was found (or row had no objects), append it
      if (!itemFound) {
        updatedRow.push(data);
      }

      return prev.map((row, idx) => (idx === rowIndex ? updatedRow : row));
    });
  }, []);

  // 4. write_value(value, status):
  // Iterates through ALL items across the entire 2D array.
  // When item.value === value, updates ONLY status (keeps name and value unchanged).
  const write_value = useCallback((value, status) => {
    setGrid((prev) =>
      prev.map((row) =>
        row.map((elem, idx) => {
          if (idx === 0) return elem; // Skip name name
          if (elem.value === value) {
            return {
              ...elem,
              status: status, // Update only status
            };
          }
          return elem;
        })
      )
    );
  }, []);

  return { grid, check, set, write_name, write_value, setGrid };
}