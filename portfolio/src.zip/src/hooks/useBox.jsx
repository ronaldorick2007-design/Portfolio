import { useState, useRef } from "react";
import { useScopes } from "./useSetItems";

export function useBox(generator){
    const gen = useRef(generator());
    const [stack, setStack] = useState([]);
    const [indicators, setIndicators] = useState(new Map());
    const { grid, check, set, write_name, write_value, setGrid } = useScopes([["heap"]]);

    const primitive_types = new Set(['string','number','bigint','boolean','undefined','symbol']);

    function check_type(type) {
        return primitive_types.has(type);
    }

    function reset(){
        gen.current = generator();
        setGrid([["heap"]]);
        setStack([])
    }

    function next() {
        const result = gen.current.next();

        if (result.done) {
            console.log("Done!")
            reset();
            return;
        }

        const obj = {name:result.value.name, value:result.value.value, status:result.value.status}

        if(result.value.action && result.value.action === "set"){
            console.log("function call");
            if(result.value.type === "F" && !(result.value.scope in grid)) set(result.value.scope);
            else if(result.value.type === "L"){
                write_name(result.value.scope, obj)
            }
            else if(result.value.type === "H"){
                write_name("heap", obj)
            }
        }



        // if(result.value.set){if(result.value.set && result.value.set === "F"){
        //     console.log("function call");
        //     if(!(result.value.scope in grid)) set(result.value.scope);
        // }

        // if(result.value.set && result.value.set === "N"){
        //     console.log("Initialization");
        //     const x = {name:result.value.name, value:result.value.value, status:result.value.status}
        //     if(check_type(typeof result.value.value)){
        //         console.log("primitive, so in scope",result.value.scope);
        //         write_name(result.value.scope, x)
        //     }
        //     else if(result.value.scope === "console"){
        //         write_name(result.value.scope, x)
        //     }
        //     else{
        //         console.log("non-primitive so in heap");
        //         write_name("heap", x)
        //     }            
        // }}
        else if(result.value.action === "point"){
            const obj = {name:result.value.name, value:result.value.value.className, status:result.value.status}
            write_name(result.value.scope, obj);
            setIndicators(prevMap => {
                const nextMap = new Map(prevMap);
                nextMap.set(result.value.name, result.value.value);
                return nextMap; // New reference triggers re-render
            });
        }

        else {
            if(result.value.type === "H"){
                write_name("heap", obj)
            }
            else if(result.value.type === "L"){
                write_name(result.value.scope, obj)
            }
        }
        
        
        // else{if(check_type(typeof result.value.value)){
        //     const x = {name:result.value.name, value:result.value.value, status:result.value.status}
        //     console.log("primitive",x);
        //     write_name(result.value.scope, x)
        // }
        // else{
        //     const x = {name:result.value.name, value:result.value.value, status:result.value.status}
        //     console.log("non-primitive");
        //     write_name(result.value.scope, x)
        // }}


        

        // console.log(stack);
    //     setStack((prevArr) => {
    //     const index = prevArr.findIndex((item) => item.value === result.value.value);

    //     if (index !== -1) {
    //     // Overwrite the existing item at that index
    //     return prevArr.map((item, i) => (i === index ? result.value : item));
    //     }

    //     // Otherwise, append to the end
    //     return [...prevArr, result.value];
    // });

console.log(grid)
console.log(indicators)
    
    }

    return { next ,stack,grid,indicators};
}