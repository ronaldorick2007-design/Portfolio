import { useState, useRef } from "react";

export default function useArray() {
    const [name, setName] = useState()
    const [item, setItem] = useState();
    const [active, setActive] = useState([]);

    function reset() {
        setName()
        setItem();
        setActive([]);
    }

    function apply({ action,index,name }) {
        switch (action) {
            case "set":
                setName(name)
                setItem(index.toString());
                break;

            case "active":
                setActive(index);
                break;

            case "rearrange":
                setItem(index);
                break;

            case "reset":
                reset();
                break;
        }
    }

    return {
        name,
        item,
        active,
        apply,
    };
}