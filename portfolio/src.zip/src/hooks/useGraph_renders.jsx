import { useEffect, useState } from "react";
import { useRef } from "react";
import { Queue } from "../data_structures/Queue";

export default function useGraph(){

    const datastructure = useRef(null)

    const [name, setName] = useState("");
    const [arr, setArr] = useState([]);
    const [connect, setConnect] = useState([])
    const [indicate, setIndicate] = useState(() => new Map());

    function apply({action, index, name}) {
 
            switch (action) {

                case "set":
                    datastructure.current = index;
                    setName(name);
                    toArray(index);
                    break;

                case "indicate":                   
                    const [node, status] = index;
                    setIndicate(new Map().set(node, status));
                    break;
    
                case "rearrange":
                    toArray(index);
                    break;
    
                default:
                    break;
            }
       
    }      

    function getPostion(N,n){
        let a = Math.round(n*4/5);
        let b = n;
        let x = Math.round(a*Math.sin((N+1)*2*Math.PI / n) + b);
        let y = Math.round(a*Math.cos((N+1)*2*Math.PI / n) + b);
        return [x,y]
    }

    function toArray(index){
        let step = 36;
        let size = 30;
        let Keys = Object.keys(index)
        let n = Keys.length;
        setArr(Keys)
        let temp = []
        
        Keys.map((k,i) => {
            let [x1,y1] = getPostion(i,n);
            index[k].map((v,i)=>{
                let [x2,y2] = getPostion(Keys.indexOf(`${v}`),n);
                temp.push([
                    x1*step+size/2,
                    y1*step+size/2,
                    x2*step+size/2,
                    y2*step+size/2])
                })
        })
        setConnect(temp)
    }

    return {
            name,
            arr,    
            indicate,
            connect,
            apply,
            getPostion
        };
    }
