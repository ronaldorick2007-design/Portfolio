import { useState, useRef } from "react";
  
export default function useArray() {
    const array = useRef(null);
    const [name, setName] = useState("");
    const [arr, setArr] = useState([]);

    const [indicate, setIndicate] = useState(() => new Map());

    const [active, setActive] = useState([]);
    const [match, setMatch] = useState([]);

    const [swap, setSwap] = useState({});
    const [pass, setPass] = useState([]);
    const [hold, setHold] = useState([]);
    const [change, setChange] = useState([]);

    function reset() {
        setSwap({})
        setArr([]);
        setActive([]);
        setMatch([]);
        setPass([]);
        setHold([]);
    }

    function apply({ action,index,name,d }) {
        switch (action) {
            case "set":
                array.current = index;
                setArr([...array.current]);
                setName(name);
                break;

            case "swap":
                if(d!==array.current) break;
                setSwap(index);
                break;
 
            case "indicate": 
                    if(d!==array.current) break;
                    const [node, status] = index;
                    const nodes = Array.isArray(node) ? node : [node];

                    setIndicate((prevMap) => {
                    const newMap = new Map();

                    // 1. If NOT "pass", drop any existing entries with this status (overwrite)
                    //    If "pass", keep all existing entries (append)
                    for (const [k, v] of prevMap.entries()) {
                        if (status === 'pass' || v !== status) {
                        newMap.set(k, v);
                        }
                    }

                    // 2. Add / update incoming nodes with the new status
                    nodes.forEach((n) => {newMap.set(n, status);
                    });

                    return newMap;
                    });
                    break;

            case "active":
                setActive(index);
                break;

            case "match":
                setMatch(index);
                break;

            case "rearrange":
                setArr([...array.current]);
                setSwap({})
                break;    

            case "pass":
                setPass(prev => [...prev, ...index]);
                break;

            case "hold":
                setHold(index)
                break;
            
            case "change":
                setChange(index)
                break;

            case "reset":
                reset();
                break;
        }
    }

    return {
        name,
        arr,
        indicate,
        active,
        apply,
        match,
        swap,
        pass,
        hold,
        change
    };
}