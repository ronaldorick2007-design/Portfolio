import { useState, useRef, useEffect } from 'react';
import { flushSync } from 'react-dom';
import ArrayVisual from "../components/ArrayVisualCopy";
import LinkedListVisual from "../components/ALinkedListVisual";
import TreeVisual from '../components/ATreeVisual';
import APrimitiveVisual from '../components/APrimitiveVisual';
import NodeVisual from '../components/ANodeVisual';
import SetVisual from '../components/ASetVisual';
import MapVisual from '../components/AMapVisual';
import Empty from '../components/Empty';
import GraphVisual from '../components/AGraphVisual';


export function useComponentRegistry(generator, delay=1000) {
  const [items, setItems] = useState({}); // { [id]: Component }
  const refs = useRef({}); // HashMap: { [id]: ref }
  const gen = useRef(generator());
  const [log, setLog] = useState("");
  const [running, setRunning] = useState(false);

  const registry = new Map([
    ['A', ArrayVisual],
    ['L', LinkedListVisual],
    ['SinglyLinkedList', LinkedListVisual],
    ['DoublyLinkedList', LinkedListVisual],
    ['Stack', LinkedListVisual],
    ['Queue', LinkedListVisual],
    ['T', TreeVisual],
    ['Tree', TreeVisual],
    ['P', APrimitiveVisual],
    ['S', SetVisual],
    ['Set', SetVisual],
    ['M', MapVisual],
    ['Map', SetVisual],
    ['N', NodeVisual],
    ['G',GraphVisual]
  ])

  function apply(value) {
        // Split/normalize value into an array of action objects
        const actions = Array.isArray(value) ? value : [value];
    
        actions.forEach(actionObj => {
            const { action, index, name, type ,scope,d,disp} = actionObj;
            const scope_name = scope ? `${scope}-${name}`:`main-${name}`;
            // const scope_name = [scope, name].filter(Boolean).join("-");  
             
            refs.current[scope_name]?.apply({
                  action: action,
                  index: index
                });           

            switch (action) {
              case "set":
                if(type==="F"){
                  flushSync(() => {
                  setItems((prev) => ({ ...prev, [scope_name]: Empty }));
                });
                break;
                }

                flushSync(() => {
                  setItems((prev) => ({ ...prev, [scope_name]: registry.get(type) }));
                });
                refs.current[scope_name]?.apply({
                  action: "set",
                  index: index,
                  name: name,
                  disp:disp
                });
                break;
               
              case "indicate":
                if(name!=null){break}
                Object.values(refs.current).forEach(I=> {
                  if(I==null){return;}
                  I.apply({
                  action: "indicate",
                  index: index,
                  d:d
                })
            })
                break;

                case "rearrange":
                if(name!=null){break}
                Object.values(refs.current).forEach(I=> {
                  if(I==null){return;}
                  I.apply({
                  action: "rearrange",
                  index: index,
                  d:d
                })
            })
                break;
              
              case "log":
                setLog(index);
                break;
              
              case "clear":
  setItems((prevItems) => {
    return Object.fromEntries(
      Object.entries(prevItems).filter(
        ([key]) => !key.startsWith(`${scope}-`)
      )
    );
  });
  break;
              
              case "reset":
                reset();
                break;

              default:
                break;
            }
        });
    }

    function reset(){
      Object.values(refs.current).forEach((refHandle) => {
        refHandle?.apply({action : "reset",index:[]});
      });
      setItems({})
      gen.current = generator();
      setLog("");
    }
  
    function next() {
        const result = gen.current.next();

        if (result.done) {
            reset();
            return;
        }

        apply(result.value);
    }

    useEffect(() => {
            if (!running) return;
    
            const id = setInterval(() => {
                const result = gen.current.next();
    
                if (result.done) {
                    clearInterval(id);
                    setRunning(false);
                    reset();
                    return;
                }
    
                apply(result.value);
            }, delay);
    
            return () => clearInterval(id);
        }, [running, delay]);
    
        function start() {
            setRunning(prev => !prev);
        }
    
        function stop() {
            setRunning(false);
            reset();
        }

    const groups = Object.entries(items).reduce((acc, [id, Comp]) => {
      const [A] = id.split('-');
      (acc[A] = acc[A] || []).push([id, Comp]);
      return acc;
    }, {});

const render = () => (
  <>
    {Object.entries(groups).map(([A, list]) => (
      <div 
        key={A} 
        className="text-center flex gap-10 border-2 border-black m-2 p-2 items-center "
      >
        {A}
        {list.map(([id, Comp]) => (
          <Comp key={id} ref={(r) => (refs.current[id] = r)} />
        ))}
      </div>
    ))}
  </>
);

  return { refs: refs.current, render, next, log ,running,
        start,
        stop,
        next};
}