import { useEffect, useState } from "react";
import { useRef } from "react";

export default function useLinkedList(){

    const datastructure = useRef(null)
 
    const [name, setName] = useState("");
    const [arr, setArr] = useState([]);
    // const [indicate, setIndicate] = useState({});
    const [indicate, setIndicate] = useState(() => new Map());


    const callbackRef = useRef(null);
    

    function reset() {
        }

    function apply({action, index,name,disp}) {     
            switch (action) {

                case "set": 
                    datastructure.current = index;
                    setName(name)
                    if(disp){
                        callbackRef.current = {disp};
                    }
                    toArray();

                    break;

                case "indicate":
                    const [node, status] = index;
                    setIndicate(new Map().set(node, status));
                    break;

                case "rearrange":
                    toArray();
                    break;
    
                default:
                    break;
            }

    }
  
    function toArray(){
        let current = datastructure.current.head;
        let temp = []
        while(current!=null){
          temp.push(current)
          current = current.next
        }

        temp = callbackRef.current.disp?.(datastructure.current)
        console.log("From LL hook", callbackRef.current.disp?.(datastructure.current))
        setArr(temp);        
    }
    return {
            name,
            arr,
            indicate,
            apply
        };
    }
