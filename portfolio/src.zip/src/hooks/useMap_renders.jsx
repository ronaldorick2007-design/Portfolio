import { useEffect, useState } from "react";
import { useRef } from "react";

export default function useMap(){

    const datastructure = useRef(null) 
    const [name, setName] = useState("");
    const [arr, setArr] = useState([]);
    const [indicate, setIndicate] = useState(() => new Map());

    function reset() {
        }
 
    function apply({action, index,name}) {     
            switch (action) {

                case "set":                    
                    datastructure.current = index;
                    setName(name)
                    setArr(Array.from(datastructure.current));
                    break;

                case "indicate":
                    const [node, status] = index;
                    setIndicate(new Map().set(node, status));
                    break;

                case "rearrange":
                    setArr(Array.from(datastructure.current));

                    // toArray();
                    break;
    
                default:
                    break;
            }

    }
  
    function toArray(){
        let current = datastructure.current.head;
        let temp = []
        while(current!=null){
          temp.push(current)
          current = current.next
        }
        setArr(temp);        
    }
    return {
            name,
            arr,
            indicate,
            apply
        };
    }
