import { useState, useRef } from "react";
 
export default function useArray() {
    const array = useRef(null);
    const [name, setName] = useState("");
    const [arr, setArr] = useState([]);

    const [indicate, setIndicate] = useState(() => new Map());

    const [active, setActive] = useState([]);
    const [match, setMatch] = useState([]);

    const [swap, setSwap] = useState({});
    const [pass, setPass] = useState([]);
    const [hold, setHold] = useState([]);
    const [change, setChange] = useState([]);

    function reset() {
        setSwap({})
        setArr([]);
        setActive([]);
        setMatch([]);
        setPass([]);
        setHold([]);
    }

    function apply({ action,index,name }) {
        switch (action) {
            case "set":
                array.current = index;
                setArr([...array.current]);
                setName(name);
                break;

            case "swap":
                setSwap(index);
                break;

            case "indicate":
                    const [node, status] = index;
                    setIndicate(new Map().set(node, status));
                    break;

            case "active":
                setActive(index);
                break;

            case "match":
                setMatch(index);
                break;

            case "rearrange":
                setArr([...array.current]);
                setSwap({})
                break;    

            case "pass":
                setPass(prev => [...prev, ...index]);
                break;

            case "hold":
                setHold(index)
                break;
            
            case "change":
                setChange(index)
                break;

            case "reset":
                reset();
                break;
        }
    }

    return {
        name,
        arr,
        indicate,
        active,
        apply,
        match,
        swap,
        pass,
        hold,
        change
    };
}