import React, { useState, useRef, useEffect } from 'react';
import { flushSync } from 'react-dom';
import ArrayVisual from "../components/ArrayVisual";
import LinkedListVisual from "../components/ALinkedListVisual";
import TreeVisual from '../components/ATreeVisual';
import APrimitiveVisual from '../components/APrimitiveVisual';

export function useComponentRegistry(generator) {
  const [items, setItems] = useState({}); // { [id]: Component }
  const [delay, setDelay] = useState(1000)
  const refs = useRef({}); // HashMap: { [id]: ref }
  const gen = useRef(generator());
  const [log, setLog] = useState("");
  const [running, setRunning] = useState(false);

  const registry = new Map([
    ['A', ArrayVisual],
    ['L', LinkedListVisual],
    ['T', TreeVisual],
    ['P', APrimitiveVisual]
  ])

  function apply(value) {
        // Split/normalize value into an array of action objects
        const actions = Array.isArray(value) ? value : [value];
    
        actions.forEach(actionObj => {
            const { action, index, name, type ,scope} = actionObj; 
            const scope_name = scope ? `${scope}-${name}`:name;  
            
            refs.current[scope_name]?.apply({
                  action: action,
                  index: index
                });

            switch (action) {
              case "set":

                flushSync(() => {
                  setItems((prev) => ({ ...prev, [scope_name]: registry.get(type) }));
                });
                refs.current[scope_name]?.apply({
                  action: "set",
                  index: index
                });
                break;
              
              case "log":
                setLog(index);
                break;
              
              case "clear":
                setItems((prevItems) => {
                  const { [scope_name]: _, ...rest } = prevItems;
                  return rest;
                });
                break;
              
              case "reset":
                reset();
                break;

              default:
                break;
            }
        });
    }

    function freq(delay){
      setDelay(delay);
    }

    function reset(){
      Object.values(refs.current).forEach((refHandle) => {
        refHandle?.apply({action : "reset",index:[]});
      });
      setItems({})
      gen.current = generator();
      setLog("");
    }
  
    function next() {
        const result = gen.current.next();

        if (result.done) {
            reset();
            return;
        }

        apply(result.value);
    }

    useEffect(() => {
            if (!running) return;
    
            const id = setInterval(() => {
                const result = gen.current.next();
    
                if (result.done) {
                    clearInterval(id);
                    setRunning(false);
                    reset();
                    return;
                }
    
                apply(result.value);
            }, delay);
    
            return () => clearInterval(id);
        }, [running, delay]);
    
        function start() {
            setRunning(prev => !prev);
        }
    
        function stop() {
            setRunning(false);
            reset();
        }

  const render = () => (
    <>
      {Object.entries(items).map(([id, Comp]) => (
        <Comp key={id} ref={(r) => (refs.current[id] = r)} />
      ))}
    </>
  );

  return { refs: refs.current, render, next, log ,running,
        start,
        stop,
        next,freq};
}