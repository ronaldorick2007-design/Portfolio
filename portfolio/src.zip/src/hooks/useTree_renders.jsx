import { useEffect, useState } from "react";
import { useRef } from "react";
import { Queue } from "../data_structures/Queue";

export default function useTree(){

    const datastructure = useRef(null)

    const [name, setName] = useState("");
    const [arr, setArr] = useState([]);
    const [indicate, setIndicate] = useState(() => new Map());

    function reset() {
        setArr([]);
    }


    function apply({action, index, name}) {
 
            switch (action) {

                case "set":
                    datastructure.current = index;
                    setName(name);
                    toArray();
                    break;

                case "indicate":                   
                    const [node, status] = index;
                    setIndicate(new Map().set(node, status));
                    break;
    
                case "rearrange":
                    toArray();
                    break;
    
                default:
                    break;
            }
       
    }      

    function toArray(){
        root = datastructure.current;
        let temp = [];
        let q = new Queue();
        q.enqueue(root);
        while(!q.isEmpty()){
            let parent = q.dequeue()

            if(parent!==null){
                temp.push(parent)
                q.enqueue(parent.left);
                q.enqueue(parent.right);
            }
            else temp.push(null)
        }

        while(!temp.at(-1)){
            temp.pop()
        }

        setArr(temp)
    }

    return {
            name,
            arr,    
            indicate,
            apply
        };
    }
