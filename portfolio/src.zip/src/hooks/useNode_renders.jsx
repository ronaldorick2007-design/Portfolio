import { useEffect, useState } from "react";
import { useRef } from "react";

export default function useNode(){

    const datastructure = useRef(null)
 
    const [name, setName] = useState("");
    const [node, setNode] = useState([]);
    const [indicate, setIndicate] = useState(() => new Map());

    function reset() {
        }

    function apply({action, index,name}) {     
            switch (action) {

                case "set": 
                    datastructure.current = index;
                    setName(name)
                    setNode([datastructure.current]);
                    break;

                case "indicate":
                    const [node, status] = index;
                    setIndicate(new Map().set(node, status));
                    break;

                case "rearrange":
                    setNode([datastructure.current]);
                    break;
    
                default:
                    break;
            }

    }
  
    return {
            name,
            node,
            indicate,
            apply
        };
    }
